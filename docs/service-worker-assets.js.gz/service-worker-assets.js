﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-m1j9QKrzS4aarePvS1ujYGAkqMTr3F4cFN0ipNeESWs=",
      "url": "card-images\/Card01_01.png"
    },
    {
      "hash": "sha256-Q+vRE1PnkMxPdONa0\/7ebzHqoWUY+OPy7XviIB2UYAo=",
      "url": "card-images\/Card01_02.png"
    },
    {
      "hash": "sha256-iDaSpY42bZ0uzhYsjQtzQxZy8uFa8SbTis5UutLIfTk=",
      "url": "card-images\/Card01_03.png"
    },
    {
      "hash": "sha256-aPL0E\/2rbiYOKafG1dFli+jJJM5+2jhXw9NesS9qjxs=",
      "url": "card-images\/Card01_04.png"
    },
    {
      "hash": "sha256-cmTq2CY5pyukMj2YRFrTq6yGjqYyXex\/YxIh3roykc4=",
      "url": "card-images\/Card01_05.png"
    },
    {
      "hash": "sha256-5O03E0QqXZYnSz5DN75aZC4z5sBQSXd\/AUPHT0f5vwM=",
      "url": "card-images\/Card01_06.png"
    },
    {
      "hash": "sha256-V6MwZqrD6Kn+Rl9M6tAZSr3c2j9WPcnv4gAyeTEFT6Q=",
      "url": "card-images\/Card01_07.png"
    },
    {
      "hash": "sha256-BzahjDwxTwnfuAWNUCdaejfzNmdABFRPxrJJMXYwc30=",
      "url": "card-images\/Card01_08.png"
    },
    {
      "hash": "sha256-7rATCS3gACYzUmneV1JHfui9R6G1aMx6d08nkZhgwEw=",
      "url": "card-images\/Card01_09.png"
    },
    {
      "hash": "sha256-rOOsHWebU9nnJxvkrt\/4+ED5um8aTurKHXLWZ\/aEBnQ=",
      "url": "card-images\/Card01_10.png"
    },
    {
      "hash": "sha256-Wvvq0LSLXUXeRC21rE7rkP25MeL1u3eHw4ut22\/gX4k=",
      "url": "card-images\/Card01_11.png"
    },
    {
      "hash": "sha256-ethFFuzjRCPt157nvVZGSFAzDib44R\/arctWNpywNig=",
      "url": "card-images\/Card01_12.png"
    },
    {
      "hash": "sha256-5HBFlQTnj85cVbheOLU+5f1HflxqxGVIOblbsiYPfLw=",
      "url": "card-images\/Card02_01.png"
    },
    {
      "hash": "sha256-UTlkFJUCnODh3QsTHaBnkiayqW5qloUQhAxPBWBf\/b4=",
      "url": "card-images\/Card02_02.png"
    },
    {
      "hash": "sha256-3c8Fxvlge4YtVfoWyUsBOPmFHJiroBLaUef+Jaa49dg=",
      "url": "card-images\/Card02_03.png"
    },
    {
      "hash": "sha256-Szjyie4O0LrxQo3UuIY9ypH+NKk7GUGUWZvOjYVEfx8=",
      "url": "card-images\/Card02_04.png"
    },
    {
      "hash": "sha256-CzwfRJiTP1SWDunlxLbYLOI8Wiao83\/PgrF0aPP8Gt8=",
      "url": "card-images\/Card02_05.png"
    },
    {
      "hash": "sha256-0TcQYTUwxBgiuwMV9efKtt\/sf7SF6sLmG+0NUw2jZ84=",
      "url": "card-images\/Card02_06.png"
    },
    {
      "hash": "sha256-zRwiHsXrc46HGIMUoXu+JtLtCsqWa000lxf99hGBtoc=",
      "url": "card-images\/Card02_07.png"
    },
    {
      "hash": "sha256-aHOANSUHuIiq0hn37NGqGOZzC6laoQuQpIwPJeaPDXI=",
      "url": "card-images\/Card02_08.png"
    },
    {
      "hash": "sha256-Gakjr9nOYihezMmxXvmfzDUABalGnoG64VgdLOfvaDc=",
      "url": "card-images\/Card02_09.png"
    },
    {
      "hash": "sha256-Gsc8z5114jcLkwYhUxB9bQkVh+XDLXRjmhbQ5gX\/qVc=",
      "url": "card-images\/Card02_10.png"
    },
    {
      "hash": "sha256-U28sdfZbiQJ47LCUq\/AyU3fdKM8oZupx\/A7nyxn\/3tY=",
      "url": "card-images\/Card02_11.png"
    },
    {
      "hash": "sha256-JhaDDdL\/hbN7mQygJlIj9r9VilVlN52P34AX2B+bCMk=",
      "url": "card-images\/Card02_12.png"
    },
    {
      "hash": "sha256-JWUyMaAKxRLcizHa9SVZGy4ejT9K4cXodHvTB22Uonc=",
      "url": "card-images\/Card03_01.png"
    },
    {
      "hash": "sha256-w2avPtyEGNfgGFuz4YPAzuDkKqACLZ6wNncaoCi1AN4=",
      "url": "card-images\/Card03_02.png"
    },
    {
      "hash": "sha256-88I3Pwi6hzf9q+60TbjXz6MxJJKQsc6AjZqlITv\/p0w=",
      "url": "card-images\/Card03_03.png"
    },
    {
      "hash": "sha256-g\/7Usneo7AcKjXBUmlZ+bDJEagI\/k49rqqd5Gmr8Clg=",
      "url": "card-images\/Card03_04.png"
    },
    {
      "hash": "sha256-Phil9e157iRJLYU094TsOTEBR4wSUhwDfcc4sHk+c0Y=",
      "url": "card-images\/Card03_05.png"
    },
    {
      "hash": "sha256-Tl3uJyBprDdF1FnxsCp5cHMilHlH6FPREW06veeOQ3Q=",
      "url": "card-images\/Card03_06.png"
    },
    {
      "hash": "sha256-J0hhnk+ZFbjE5CmL4KTmhtuRxFKifWl1\/xjUQeYfyrE=",
      "url": "card-images\/Card03_07.png"
    },
    {
      "hash": "sha256-CP+eB\/JpppVGpFkZGLUXr49hwoutBQNfyEAXjlR+FLE=",
      "url": "card-images\/Card03_08.png"
    },
    {
      "hash": "sha256-rOZb8om2IZ\/5zRW6jxRoYJDhy18xXfp2fQ+GBRV5Ht0=",
      "url": "card-images\/Card03_09.png"
    },
    {
      "hash": "sha256-z86Jb50o7g6MrqVYbmiLXrf8hNn1HY8Bkt1AzErNOyM=",
      "url": "card-images\/Card03_10.png"
    },
    {
      "hash": "sha256-Cne3cAabYCBGcnlQIKJKl3lR1CnoD1n32Y8lXvGpwpg=",
      "url": "card-images\/Card03_11.png"
    },
    {
      "hash": "sha256-XlDJRwtcvLaTEemxVbjt4FYmEph4v2thKexkNIUnQ48=",
      "url": "card-images\/Card03_12.png"
    },
    {
      "hash": "sha256-uBrFz+8nA2UHTbiC842WGQIam44adJe+f2jSqmdn660=",
      "url": "card-images\/Card04_01.png"
    },
    {
      "hash": "sha256-FgyX2\/F6x5USQf88Voz9yLfyYoLO+TlsZ9LscMIPWng=",
      "url": "card-images\/Card04_02.png"
    },
    {
      "hash": "sha256-WJ8T7lf5dz6fmTsnwz6CfT8qK8uIyY0QKWi\/NMBuiG0=",
      "url": "card-images\/Card04_03.png"
    },
    {
      "hash": "sha256-G2kCxwyCQ6gsN7nAr9ZeoRHF+73gRHx47XNkbjtPkvw=",
      "url": "card-images\/Card04_04.png"
    },
    {
      "hash": "sha256-FANhLRHpQoq2biM4rKGT\/tYw1+yijmObxNMBLTH8D60=",
      "url": "card-images\/Card04_05.png"
    },
    {
      "hash": "sha256-yC0NAdOtvY4X50BMz1hTmjZHr\/FtqIhvl1YApe3J7Eg=",
      "url": "card-images\/Card04_06.png"
    },
    {
      "hash": "sha256-ftisnI2u4VaoyXdffpruZfEIiJN7Bi39Zxnby8Zu0Qc=",
      "url": "card-images\/Card04_07.png"
    },
    {
      "hash": "sha256-BDiWdmFY5cHEYYdGomxxLAQbs1b42nl5LAoZvVIDhLI=",
      "url": "card-images\/Card04_08.png"
    },
    {
      "hash": "sha256-IT6nWrzm7r4cp4coqBV+x1Sqm3ohC+t8k92FtV03Tk0=",
      "url": "card-images\/Card04_09.png"
    },
    {
      "hash": "sha256-zd4pSQDvj2iOoaManHphblFt5WwJrgwcgZrXoYrxAJM=",
      "url": "card-images\/Card04_10.png"
    },
    {
      "hash": "sha256-W1Nuc5q8JzWBY49HyBV\/l7cBGSp285qNokF8IhjgbEI=",
      "url": "card-images\/Card04_11.png"
    },
    {
      "hash": "sha256-RgeLj7T93G0aNkTgUyvNbg9T1yOgxHt9ARWC2PKLFps=",
      "url": "card-images\/Card04_12.png"
    },
    {
      "hash": "sha256-X0OvXAV24CbVci9RTC2kCFCDG\/i5r0UzDL8569CtZZ0=",
      "url": "card-images\/Card05_01.png"
    },
    {
      "hash": "sha256-AoPFvTtZwWBCOF797FFT0AZSnUNSlgiAfCa3NB75wAg=",
      "url": "card-images\/Card05_02.png"
    },
    {
      "hash": "sha256-CzSzq3dREQLkx9qSAwnp2t1sF6+ZqM4XplULEzLkhWE=",
      "url": "card-images\/Card05_03.png"
    },
    {
      "hash": "sha256-ytyceZ\/0JXI\/wJHhRZPRKxFI5p6tGSUMYxbCaTPABXc=",
      "url": "card-images\/Card05_04.png"
    },
    {
      "hash": "sha256-6GyHqSGVZQhhva4lfqBkyso7zu6ccIdITVf5urjGnAE=",
      "url": "card-images\/Card05_05.png"
    },
    {
      "hash": "sha256-kw\/38Yb+XSL\/hJJNiaSo3zbRcG+EcN7nKopfmmxJ++8=",
      "url": "card-images\/Card05_06.png"
    },
    {
      "hash": "sha256-Gcvg36VN3KdTG5exbjbuYlFGTyf34W7TqgX6qi66myQ=",
      "url": "card-images\/Card05_07.png"
    },
    {
      "hash": "sha256-i7xezKnSkMDOrjcWCmYcHkKkX7i7CGU3gIaayAmtA\/c=",
      "url": "card-images\/Card05_08.png"
    },
    {
      "hash": "sha256-XDNP5Aq5D8E2jgE8fouUEr80FSOhEo9eFZlj645NR6c=",
      "url": "card-images\/Card05_09.png"
    },
    {
      "hash": "sha256-GoSaVXdqZxJGMGosqDDhkCckDDzU53P25WWLvm62MgU=",
      "url": "card-images\/Card05_10.png"
    },
    {
      "hash": "sha256-WRTqZynY98bnhDN+qcghLHxyZrfkxi58MlrZAZBNd9A=",
      "url": "card-images\/Card05_11.png"
    },
    {
      "hash": "sha256-\/jar\/pUir+wXZEHYyPoXHRM+KIzfjt6Jx1mGJ1OcbLY=",
      "url": "card-images\/Card05_12.png"
    },
    {
      "hash": "sha256-0y\/rhND1AlTCA\/T+15sVP7sLBblGqGhMCNVO1Jh5BFA=",
      "url": "card-images\/Card06_01.png"
    },
    {
      "hash": "sha256-BTypNIj0dRcexh2YtdjfyFcW+Kp\/0TbD3Yi9VrsccpQ=",
      "url": "card-images\/Card06_02.png"
    },
    {
      "hash": "sha256-Z76s9rR1MS7XHh8sROdSRhBMhIKFTq5TU5bAi+\/BGV8=",
      "url": "card-images\/Card06_03.png"
    },
    {
      "hash": "sha256-OU7z2YsMet9WEx2HmmOFGNvrSZOTgBsRNsfSaQYKajA=",
      "url": "card-images\/Card06_04.png"
    },
    {
      "hash": "sha256-4JK+4aChh991vKY+FERpwNk8+lKp1fZUoUMQEvXrtwE=",
      "url": "card-images\/Card06_05.png"
    },
    {
      "hash": "sha256-hQz0BglVt+IfLyEzb+1Z9bSJimUVYat3dxQeIEb8Fok=",
      "url": "card-images\/Card06_06.png"
    },
    {
      "hash": "sha256-HswL748+1u9dXDcsHFkPY8VBFv4sVCQqPxSGEZY0LlQ=",
      "url": "card-images\/Card06_07.png"
    },
    {
      "hash": "sha256-nqyyNfc3ZP4+FQ9ST2X\/VOnXShc8JAW6P4A2UeI8QHo=",
      "url": "card-images\/Card06_08.png"
    },
    {
      "hash": "sha256-2TxVomdBFdCzMVPJVpgX1cK+MiGaac8qe96ITATHgVo=",
      "url": "card-images\/Card06_09.png"
    },
    {
      "hash": "sha256-DHoyHq8NV39++qsqSYJZhEnYc7\/Fh2RZJIYgTdZp0sQ=",
      "url": "card-images\/Card06_10.png"
    },
    {
      "hash": "sha256-xfXcM1BApwZTH88svVxxSUn\/6UoxHOVyX3WHp0E5qLY=",
      "url": "card-images\/Card06_11.png"
    },
    {
      "hash": "sha256-cwmtWGpMGBDCnTFj5RoGXe0QUq6zcHtwYvlF4V6\/Upo=",
      "url": "card-images\/Card06_12.png"
    },
    {
      "hash": "sha256-JhLHoea3U4SCN\/nFL7VxDGc4EA4FLkXqPwp\/87QBRS0=",
      "url": "card-images\/Card07_01.png"
    },
    {
      "hash": "sha256-hwxZQx27lncgiz8bxsCin36nHQv5+xTSyZ1j6eg0YI0=",
      "url": "card-images\/Card07_02.png"
    },
    {
      "hash": "sha256-eFii9gl+9sq2644\/Tl2HXciCrM4y2e8pTcHox1wEgaM=",
      "url": "card-images\/Card07_03.png"
    },
    {
      "hash": "sha256-yQCkU80Ww3fOUEjk+xfbaZH7zeWalSlV\/CthTo3PjUA=",
      "url": "card-images\/Card07_04.png"
    },
    {
      "hash": "sha256-ptvNJampYopQgFTvJMgezpnQw9rtS\/mNmE7PB3a+uMA=",
      "url": "card-images\/Card07_05.png"
    },
    {
      "hash": "sha256-iKS2qZSWQ51PeqlTvMcwwdhksDCteWHv4b5nTWSsMkk=",
      "url": "card-images\/Card07_06.png"
    },
    {
      "hash": "sha256-4PDvzhG8N3B8VdPAl+Mf1Ldud\/Ry0nEw1FyYL52ivJ4=",
      "url": "card-images\/Card07_07.png"
    },
    {
      "hash": "sha256-MBSqICbWC\/GGUD1EqESKd6StJKFJvYcNx\/TGFc1Mfms=",
      "url": "card-images\/Card07_08.png"
    },
    {
      "hash": "sha256-rlq5iUSSsXNlLDcfOWWp9njUKrFgL6NIE9J5IjgSb6I=",
      "url": "card-images\/Card07_09.png"
    },
    {
      "hash": "sha256-RgTw6JiKsvCFMUKiGYp4PmGjnZz+AB\/EwDuxze2yP9U=",
      "url": "card-images\/Card07_10.png"
    },
    {
      "hash": "sha256-+ua55CpW8paCTW4GPyToUrbYE1nydnFlYh34pP\/Vctw=",
      "url": "card-images\/Card07_11.png"
    },
    {
      "hash": "sha256-TdCouiGccy5eXiJqXvS6YokJ1C79rOCH1l2YW5zdTD8=",
      "url": "card-images\/Card07_12.png"
    },
    {
      "hash": "sha256-RmPhsz3EFT5KvW\/Fk72ZndBu5J6PmvPZK8f\/g0AzYoY=",
      "url": "card-images\/Card08_01.png"
    },
    {
      "hash": "sha256-5NFFsftmCm2l\/LH\/AISwsxj8fnB2C1t0N9IC9lCN81U=",
      "url": "card-images\/Card08_02.png"
    },
    {
      "hash": "sha256-S3Nyf8kxY9zFTWPgm2XxDrxIVZe+r1CzFU7uhShsEpM=",
      "url": "card-images\/Card08_03.png"
    },
    {
      "hash": "sha256-i10aID\/QHxedw08X9DBkDNs7GXO2c9EJQed0aADHLdM=",
      "url": "card-images\/Card08_04.png"
    },
    {
      "hash": "sha256-Nof+9wUGstDQAghEdxlB5BVSGm6SN6so4MZoDBeBMR8=",
      "url": "card-images\/Card08_05.png"
    },
    {
      "hash": "sha256-R+yH2UdIj6ysF3s65M29vBra3XNx\/LKw17IJ7JOCrPA=",
      "url": "card-images\/Card08_06.png"
    },
    {
      "hash": "sha256-xijvKdl53ckUhqSVgZgXptZM45EyKxH3+rlKagMfJg4=",
      "url": "card-images\/Card08_07.png"
    },
    {
      "hash": "sha256-eWH9XIYr9cDRccwQyI5lgTEhZkGyUFE7e9Hi8u6qVbQ=",
      "url": "card-images\/Card08_08.png"
    },
    {
      "hash": "sha256-x9+h48oUdjERfQNbvM8HCkdJhBudx6FIBt2Xj\/3Ckpo=",
      "url": "card-images\/Card08_09.png"
    },
    {
      "hash": "sha256-CXkHLlySDvQx2aeuW22hHGwwiCtEVdrUS8SwXJHVmCI=",
      "url": "card-images\/Card08_10.png"
    },
    {
      "hash": "sha256-XbPcIc0wSXPItYOLwuWosZyUkNN1DS5yfcYzWQEDlhM=",
      "url": "card-images\/Card08_11.png"
    },
    {
      "hash": "sha256-OUfGoKo6ZokLQesR8oMU+ETfgMSsQ7bjfRu0Y1Cal4I=",
      "url": "card-images\/Card08_12.png"
    },
    {
      "hash": "sha256-7io1Oy2KseVyK0u62LW7vOqHx1N1OZSZQQ\/1KeXgeDw=",
      "url": "card-images\/Card09_01.png"
    },
    {
      "hash": "sha256-WFe+FdM5HFQ9J5tFM1zksfQ49nreZGislGQIML8GAJ0=",
      "url": "card-images\/Card09_02.png"
    },
    {
      "hash": "sha256-dnGpMhqgVev1KYtNv\/mouZ3rYPZ7ZWD5\/irEtA1C1FM=",
      "url": "card-images\/Card09_03.png"
    },
    {
      "hash": "sha256-qGCXXIMVL6hz7d5+\/sX+PTEoCkHgzD0mG47dvYQvM74=",
      "url": "card-images\/Card09_04.png"
    },
    {
      "hash": "sha256-YJ6bJLNvUlmaWSTlO8qifX0KL24q48a\/IT34JctskLk=",
      "url": "card-images\/Card09_05.png"
    },
    {
      "hash": "sha256-cs6p+z6veH53\/XBBQIPyGQzY+BjyC9JBiy2vZlyoJNg=",
      "url": "card-images\/Card09_06.png"
    },
    {
      "hash": "sha256-QqwXhfVmB5qSb1UoWiI\/B3KlkPdAqBhKnAwHTQWUoUQ=",
      "url": "card-images\/Card09_07.png"
    },
    {
      "hash": "sha256-BKbsAPpLg5x1pbqMoDHJSsBFe\/UaUHyxVfjsN1i6s5M=",
      "url": "card-images\/Card09_08.png"
    },
    {
      "hash": "sha256-N6zRQfpkRZHTItDvLMa9Q+WbkrEPiBKYw0ZzIV58Kqk=",
      "url": "card-images\/Card09_09.png"
    },
    {
      "hash": "sha256-QCG3qJxkg0mdlMBO6HI+qEctu3qWni8X4S37083GuI8=",
      "url": "card-images\/Card09_10.png"
    },
    {
      "hash": "sha256-W7\/7sL5m9iByqea08tYZ3wFNEgTlH2bYdxJuaZua8f4=",
      "url": "card-images\/Card09_11.png"
    },
    {
      "hash": "sha256-VvNZ0JmxXEZX8n53khGRY2nUHdzHFkAASTsQ6kh\/St4=",
      "url": "card-images\/Card09_12.png"
    },
    {
      "hash": "sha256-hgsKmGjecSrRq9Z\/MfTjS+JWRUgKY4FI6FvXcY8MreU=",
      "url": "card-images\/Card10_01.png"
    },
    {
      "hash": "sha256-MHi1RVgsWIAgZZ2qRXtLstHsILY4J988dFdN5u9bUwA=",
      "url": "card-images\/Card10_02.png"
    },
    {
      "hash": "sha256-Pdh957xG8CWbU7CfOq2CfIL62Vw2Frw4JUNN24GZvBI=",
      "url": "card-images\/Card10_03.png"
    },
    {
      "hash": "sha256-Buum2J\/Iz+xh2Bb+o\/9pFWmloptpc0C9MMRnKDeSifY=",
      "url": "card-images\/Card10_04.png"
    },
    {
      "hash": "sha256-NVk7+q5laB32UVsEmLGKKo1nompWXUbOjotEJMN4Y4E=",
      "url": "card-images\/Card10_05.png"
    },
    {
      "hash": "sha256-4R3VTz3wLs60Fknt+Ng4W2Ab0YQ2HRnO79FP7CTE9JI=",
      "url": "card-images\/Card10_06.png"
    },
    {
      "hash": "sha256-Nzu2MmZnp\/xQCURAfHMqumthu6zsYbMOt8BM3z051lQ=",
      "url": "card-images\/Card10_07.png"
    },
    {
      "hash": "sha256-atiYszHo\/pBxuX\/QKJ\/jJ7G71OW8xoAcMI0kpuBKbEI=",
      "url": "card-images\/Card10_08.png"
    },
    {
      "hash": "sha256-cxx6COlEDSISOEuttpc7vFOPDuLWXwNl3ze30C50aWc=",
      "url": "card-images\/Card10_09.png"
    },
    {
      "hash": "sha256-MFcBvpxrOJ0tKGqBGg8cW4WjjTarYMHcpUA69UtMqQU=",
      "url": "card-images\/Card10_10.png"
    },
    {
      "hash": "sha256-TmEQ5xcLAPu3SqAx7dyRHC\/xeSkw6YuOvkdnveJlXlU=",
      "url": "card-images\/Card10_11.png"
    },
    {
      "hash": "sha256-kJILNMI0nDwZf\/Mb\/9iBjlfZxsDrBCQiw4cIfqvkdkA=",
      "url": "card-images\/Card10_12.png"
    },
    {
      "hash": "sha256-Lx08HaN\/F7nK6gc+x7TpZBXZoHK+bNq\/v5lrCQsx6pw=",
      "url": "card-images\/Card11_01.png"
    },
    {
      "hash": "sha256-Z8QgbvsgwSaNZgxcqbquuWv68zZ24OYLrdrCD3G7IWg=",
      "url": "card-images\/Card11_02.png"
    },
    {
      "hash": "sha256-LH2HKKcHMESwkVSUGcXLOOwedvAs9miwJthMEKnwZns=",
      "url": "card-images\/Card11_03.png"
    },
    {
      "hash": "sha256-vnLlGePiwZeBJO3ug7z7XIiRvf9Qy\/2Nm5oHuXyUTmE=",
      "url": "card-images\/Card11_04.png"
    },
    {
      "hash": "sha256-3V8gvD61Le34wIstAh9zyeTs\/X7UtZzMs\/x02+t0bg8=",
      "url": "card-images\/Card11_05.png"
    },
    {
      "hash": "sha256-pxu6703+457RSOqt\/bacxyk6qZEKFCHXHAE6VzYj3M4=",
      "url": "card-images\/Card11_06.png"
    },
    {
      "hash": "sha256-iFxilNJAODVCLxTTkaOzprxSl\/g4Kw6ObEfWZ90AGaY=",
      "url": "card-images\/Card11_07.png"
    },
    {
      "hash": "sha256-Ekshreu0dVf4x+PUcra4BQK24sj10qp\/jnSxo70JypI=",
      "url": "card-images\/Card11_08.png"
    },
    {
      "hash": "sha256-XzJHcTOFvJrN\/+ze37ADkuhXpTKWltQKks+O1mUUxN0=",
      "url": "card-images\/Card11_09.png"
    },
    {
      "hash": "sha256-rs1KLTqEdxjNBHHNmsn39Qu6tjXsNgBx1Uv+qWhawQU=",
      "url": "card-images\/Card11_10.png"
    },
    {
      "hash": "sha256-fchiGwpala8ZR6BKeKS7nUQpxMEx4HMp3drpJTdeVOw=",
      "url": "card-images\/SpecialCard01.png"
    },
    {
      "hash": "sha256-eak7Y4rtUrv6ZXzs\/332j1Q+ekQzCirI\/WZ+MPLaUW4=",
      "url": "card-images\/SpecialCard02.png"
    },
    {
      "hash": "sha256-tftQ1iqs\/SyZE833G6SYqxSBrQTUnmt\/RdpnG7wGxo0=",
      "url": "card-images\/SpecialCard03.png"
    },
    {
      "hash": "sha256-PWj2XoXcONJnrS3tsCDKg55K8xTwgv7fSFKXB0KmUjo=",
      "url": "card-images\/SpecialCard04.png"
    },
    {
      "hash": "sha256-CR34DKwpi3J9xPtvzVIwQViScF3Naig6k5+iknXQkII=",
      "url": "card-images\/SpecialCard05.png"
    },
    {
      "hash": "sha256-AMcTmvREEYrvPE3VkWclnZJvrWvMUG4TlzQKnGbf5Fw=",
      "url": "card-images\/SpecialCard06.png"
    },
    {
      "hash": "sha256-Ebgqxqyixjgtu0GbUSAdCe2F2ciHl9YVkrlO4mFNSbw=",
      "url": "card-images\/SpecialCard07.png"
    },
    {
      "hash": "sha256-1+T9L1f3UGDYeL3RUr5jFZCkbW4xLfFS4C1NWhRDNxg=",
      "url": "card-images\/SpecialCard08.png"
    },
    {
      "hash": "sha256-8aM9R9K90X6h+KPDW4OzrEh071mAs7dvAQxjBxAZQAc=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-HKO7ntWaa3I4ZlebewiOofdXlkNFai7KbisWN06ONEE=",
      "url": "help-image\/1.png"
    },
    {
      "hash": "sha256-IfpxkW68S9wec6A5h4uSe9Le8njBAp0uBAk\/Bhxh5\/Q=",
      "url": "help-image\/2.png"
    },
    {
      "hash": "sha256-I7aoa01lCdlIR0Lw30REtr\/VlRFvkYNionU9QbMnIRw=",
      "url": "help-image\/3.png"
    },
    {
      "hash": "sha256-EL40n75eI78x4Bm8x7iQ09WYcDUcVcF6nae7VEHBAB8=",
      "url": "help-image\/4.png"
    },
    {
      "hash": "sha256-goUHZ5yyJlWBl+Ho0PxTjIFqEVdZ8alHe3QlNl+1j64=",
      "url": "help-image\/calc1.png"
    },
    {
      "hash": "sha256-EVJQJMyTGoMcbdQnCGQxznvCK\/J9cS\/vSSgOUikJ3Kk=",
      "url": "help-image\/calc2.png"
    },
    {
      "hash": "sha256-cnOsGDCUFuM6a0iIPLV5PlN\/KDzDcXqQJ+xD+GG0BT0=",
      "url": "help-image\/calc3.png"
    },
    {
      "hash": "sha256-rq1r3GP3qbLUy9dloaSMV1xHikV+Oq6d1ZPBSS+MI4c=",
      "url": "help-image\/calc4.png"
    },
    {
      "hash": "sha256-vPrzo9xx\/NDyI\/13Ypza2DWGIYG7cmTyB\/vehPIXDfU=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-sRvVf4XzqiGlCai9FkmO7W8wXyn0J\/00856dN97hATo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-yPV5vrdT9cIyWUhVsovux6Z9RNVEsvFOe4jE4cDiLk8=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-WU\/XmUn6LEK2VOOdyAtkC6Vh2R9Adh+wIl16y74XXBc=",
      "url": "_framework\/Microsoft.CSharp.dll"
    },
    {
      "hash": "sha256-TcReBfDd2McKyEbcdvA1vRmvpL5U1gRkhznMXBxkR9A=",
      "url": "_framework\/Microsoft.VisualBasic.Core.dll"
    },
    {
      "hash": "sha256-xRMTAKo58I8WAbd3FF\/rmdji52hVbmZjM5Td1Ytgn+0=",
      "url": "_framework\/Microsoft.VisualBasic.dll"
    },
    {
      "hash": "sha256-q8nbvOC3wczldZr9NZF1UokIjK6AFBXXIk5314xZP\/M=",
      "url": "_framework\/Microsoft.Win32.Primitives.dll"
    },
    {
      "hash": "sha256-rKBQuvZn7dUCHnXjqLOHPh9Q2mAdx1+tmljEgigRrVI=",
      "url": "_framework\/Microsoft.Win32.Registry.dll"
    },
    {
      "hash": "sha256-EtGHZeFYS3EQjY36d2bGUhi1RoUSiRcCwdfL4jlSk0I=",
      "url": "_framework\/System.AppContext.dll"
    },
    {
      "hash": "sha256-PSR5ks16V5w1kpgXvglA+9CkVuCRlujbCk2Dq6v4\/2U=",
      "url": "_framework\/System.Buffers.dll"
    },
    {
      "hash": "sha256-xRwiyLpzO65CAH6MSaaxeJj8OWvsuYyuFnKU\/RbTscQ=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-NQAABhWxNjB2J6b3NQ\/LxVIBL0lARg1lW\/gyyKjrzzE=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-dmGnJIxyaR80tbV\/X7uMg29xuiKk3u6JCkD1ai8bMxU=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-U7ebUlsIdZ1sXRZteFbQXBwkcrC1fjGk+4dlZ4PZbsU=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-biiRxnFUHbRuNpv9JEIvmFr+8HfUlUhcSiaPdqez6hc=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-Gi2zlA6m0XHFVFmxBsDOKa1CLp9UAiH7Vorjy50QFOg=",
      "url": "_framework\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-xQTWSOaTzrSc1zgJA+Vf5rjhPFkcPIwje45p6a1wG6c=",
      "url": "_framework\/System.ComponentModel.DataAnnotations.dll"
    },
    {
      "hash": "sha256-HNWv52cSS8q0asySzhehyvVDFK+5YhvMWnBCV0ZkyJ4=",
      "url": "_framework\/System.ComponentModel.EventBasedAsync.dll"
    },
    {
      "hash": "sha256-WrxdWtfxeP00bf4wjrd6Jw3zt3OhxQ8PAC4pIgcmHp4=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-mFYT3pMCBIJPTgh+UGT4YoJtMeWNV94iL4OxPFI7HzA=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-CmDYZNqK+RqJcITdP493c7ahH5t3LXuNcbrXaHseIXI=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-r5J7DTpAqcppFtqfWJ0+DByK3ORiJC8O\/eZrOGW5GRc=",
      "url": "_framework\/System.Configuration.dll"
    },
    {
      "hash": "sha256-wDgym3S7LZznk85CwbJEFqlefVWcYCWmrt6mT\/ufcug=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-+0LgQ6ExzZHRxTHF3S3HzwC8lirySwHZ8rH2imsIxmY=",
      "url": "_framework\/System.Core.dll"
    },
    {
      "hash": "sha256-orQJBxrviYTbdUu56s3zvRECVkMGnBZx\/D\/9EZYNq0w=",
      "url": "_framework\/System.Data.Common.dll"
    },
    {
      "hash": "sha256-j\/UZHS45TCgJo4++9tNu1XBQPdqb9fJoZX3SOHY0cJo=",
      "url": "_framework\/System.Data.DataSetExtensions.dll"
    },
    {
      "hash": "sha256-25Aw7mk79xu0hHFj+eL\/YOigfYBOSzgHqrUILPsrL4M=",
      "url": "_framework\/System.Data.dll"
    },
    {
      "hash": "sha256-F8\/9I64l3Akik7JpkZ7oqL7vh9NwyVyPlb2EvoITDaw=",
      "url": "_framework\/System.Diagnostics.Contracts.dll"
    },
    {
      "hash": "sha256-cAKXG5ZxZ7CuVovKV66pdHl7wf3dP97mOSGg8NxS5ds=",
      "url": "_framework\/System.Diagnostics.Debug.dll"
    },
    {
      "hash": "sha256-QfSpoSqepnHBADMoR0TkHwI3Jg1MeWTWaQItzMOif0Y=",
      "url": "_framework\/System.Diagnostics.DiagnosticSource.dll"
    },
    {
      "hash": "sha256-QhqQK6DMiiEjFgHm+ClQfeN30xafyHj3udv6HmgkhIM=",
      "url": "_framework\/System.Diagnostics.FileVersionInfo.dll"
    },
    {
      "hash": "sha256-9otz1N+uGdbZULJL\/nZ60sHtx0C95OaPPPTfZNzIWTs=",
      "url": "_framework\/System.Diagnostics.Process.dll"
    },
    {
      "hash": "sha256-YfacV7fUwL8hnot9PCClv2qwwKVwq8dMC61fbbvBp4c=",
      "url": "_framework\/System.Diagnostics.StackTrace.dll"
    },
    {
      "hash": "sha256-\/O9Nvk2BzHYlyO0tQwiKCMuRz7BNV9Y5bFD67tFQ4FI=",
      "url": "_framework\/System.Diagnostics.TextWriterTraceListener.dll"
    },
    {
      "hash": "sha256-x5isMlsO+eWQApVm4IO6INTHkMNgeeBONz5Dnxkjm8k=",
      "url": "_framework\/System.Diagnostics.Tools.dll"
    },
    {
      "hash": "sha256-VMOGh\/q72Aft3Zzr\/MRhqszt3UnD5lCAb+85QMLTp0s=",
      "url": "_framework\/System.Diagnostics.TraceSource.dll"
    },
    {
      "hash": "sha256-RLfmB1nDx+YlJqrjFTsoVFzlrW58y8a49rf1qOkRsHE=",
      "url": "_framework\/System.Diagnostics.Tracing.dll"
    },
    {
      "hash": "sha256-1giZPoFqE2AZqaWMwoU0l3n2cdbZzksXQucilYImN0k=",
      "url": "_framework\/System.Drawing.Primitives.dll"
    },
    {
      "hash": "sha256-EnA+5v5fK3CG6ifTZXlxnruQEtTDP7AXkPkxEwe\/7sw=",
      "url": "_framework\/System.Drawing.dll"
    },
    {
      "hash": "sha256-sWK7Ox0y1jwQ4PEN1QkNAi4XT\/dUT8lcBYFJMPQlzeU=",
      "url": "_framework\/System.Dynamic.Runtime.dll"
    },
    {
      "hash": "sha256-sWYrajTP5rWcJQy35X8pjraQ84w4ACTW\/rVdZuevI\/c=",
      "url": "_framework\/System.Formats.Asn1.dll"
    },
    {
      "hash": "sha256-aIEYJtFQNw6dIhCtZm2H0Kdwm3M7mMkbf5jAeVlqoAE=",
      "url": "_framework\/System.Globalization.Calendars.dll"
    },
    {
      "hash": "sha256-hjG04Tb5iR6RXiNgN5set4T8RFZZJKFaxxVcl6BGHAE=",
      "url": "_framework\/System.Globalization.Extensions.dll"
    },
    {
      "hash": "sha256-H6wX\/HhMGkalw8V\/J2tXAxt9jPGdunFpOEUAS\/OxeG0=",
      "url": "_framework\/System.Globalization.dll"
    },
    {
      "hash": "sha256-uaOrwCb\/v1wf+7qWkVRdFYvGt1JO7yb1DZeV3fmpG6o=",
      "url": "_framework\/System.IO.Compression.Brotli.dll"
    },
    {
      "hash": "sha256-lg3LtgB9yVDM6aCXJov7F25HRF9UOjFgmOgDumfSTrc=",
      "url": "_framework\/System.IO.Compression.FileSystem.dll"
    },
    {
      "hash": "sha256-wxjNd+L701LUZmkKA++D+wqdBN8O1e7iUPjIyR334o8=",
      "url": "_framework\/System.IO.Compression.ZipFile.dll"
    },
    {
      "hash": "sha256-kz4FS7C0kMmoz7TtCND439kEuDT5gDN5bfSvVE\/xs\/8=",
      "url": "_framework\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-jAG5hKzZCBYd7WK06QF07IgCD8yOq3iXdFGMQ4vCmzE=",
      "url": "_framework\/System.IO.FileSystem.AccessControl.dll"
    },
    {
      "hash": "sha256-yNrgoGXyGIJcAgOO3k9djwjMfBMe1FxlRKo2zgFNsZ8=",
      "url": "_framework\/System.IO.FileSystem.DriveInfo.dll"
    },
    {
      "hash": "sha256-P\/bEKSQc+MnXMLxvhlAXRvbkKotyxZ3AUdJZZvZhCGg=",
      "url": "_framework\/System.IO.FileSystem.Primitives.dll"
    },
    {
      "hash": "sha256-I83Vuq2GyQYrrfBPWs5o1\/g7aBv0XJYf6sRV+OhWy1U=",
      "url": "_framework\/System.IO.FileSystem.Watcher.dll"
    },
    {
      "hash": "sha256-NRPFur7zVwhxpP9OWe0mvB9yvIaiLbx1l1Y+RZYWyF8=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-2nH4ncUygNtw27rA3vXExq3J4YSo9oRgd7Rw6aSRnT0=",
      "url": "_framework\/System.IO.IsolatedStorage.dll"
    },
    {
      "hash": "sha256-ShsPtaRIFfFlrQBrziBXii7VDHjjYO5r2nlaZlHb+NA=",
      "url": "_framework\/System.IO.MemoryMappedFiles.dll"
    },
    {
      "hash": "sha256-fam1d7n0BYHFXB9mc9cNpvrt1QK5typn4qYFpeh8x7s=",
      "url": "_framework\/System.IO.Pipes.AccessControl.dll"
    },
    {
      "hash": "sha256-43LIQMR5mB1wfzVz102Vz7bWSxVDqqDZL5IVpBJ+KBQ=",
      "url": "_framework\/System.IO.Pipes.dll"
    },
    {
      "hash": "sha256-t3yM9eymhFm8bqRWr+ad+VPjZWx\/pFabiDG61KvrgRc=",
      "url": "_framework\/System.IO.UnmanagedMemoryStream.dll"
    },
    {
      "hash": "sha256-ZJc7SXobH\/HEwZGs60INKH3P8R5Kingojl89ceM\/4dE=",
      "url": "_framework\/System.IO.dll"
    },
    {
      "hash": "sha256-0xaDSvFy3Vqi\/hbNNudzxGrJM6XoQ9aZyEHiGbs92S8=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-DrTjc5abMdKFZSBQSt0EM+ihMUBPqLM1mckTDWCrIFI=",
      "url": "_framework\/System.Linq.Parallel.dll"
    },
    {
      "hash": "sha256-Mub85f62zq9VHlrnkAXCsaD6nmLvMo1CtGhHJpSvO28=",
      "url": "_framework\/System.Linq.Queryable.dll"
    },
    {
      "hash": "sha256-H0huGZbpmdZTm4mvs1QHGYZhnegjvgK1uNsaPVXMA0A=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-SzZhUdTLIkwNh6oh7SlwYVQ5rpBLaLLHdPsI062ehzE=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-Ctz9L1qLYfOjS2ANW5QS2Hh8v9hUhqJCZdz3flEeu+8=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-LklNV3m6+jEE19JHdKWGyr2u4YUgoAdL0Fnz5c5VawY=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-hg48Zr2aXm7QVrTcnwHMNQMLf0UG7x8i8b\/WiDCsoTw=",
      "url": "_framework\/System.Net.HttpListener.dll"
    },
    {
      "hash": "sha256-rhIB2N08F\/\/dysJPO3CrfqXPsQoPHSVSo7U\/hxx7\/qA=",
      "url": "_framework\/System.Net.Mail.dll"
    },
    {
      "hash": "sha256-JVXNwJIiZDZwL\/KdZcPIam1lyWwq1oUd7Vh8F3Y\/+hA=",
      "url": "_framework\/System.Net.NameResolution.dll"
    },
    {
      "hash": "sha256-aQ1lE6zUhRM4tIIKhP0DHDLmULCapzDRGtdpB\/TsxQc=",
      "url": "_framework\/System.Net.NetworkInformation.dll"
    },
    {
      "hash": "sha256-kAilE3Ji3MXjnhVe0EcEGWZJJW5GbilOxn4lzTM9nYA=",
      "url": "_framework\/System.Net.Ping.dll"
    },
    {
      "hash": "sha256-M1SRNZqiUZHTg6PJnzEMC5HdxJha2KbHAmVia5qLths=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-Z0venEz0dFCPvE0s4BWIBtRCjxOs7bYHhTjGsm2Fl\/4=",
      "url": "_framework\/System.Net.Requests.dll"
    },
    {
      "hash": "sha256-hyhs1E3TVgUBD6OFWPrfts+0kAPMMs2vIS+BmGSXdK0=",
      "url": "_framework\/System.Net.Security.dll"
    },
    {
      "hash": "sha256-ChvHSlRgcgXZBZgC5+plRz2XoZqT1SYxE+NIQBAxNUA=",
      "url": "_framework\/System.Net.ServicePoint.dll"
    },
    {
      "hash": "sha256-hUHqZciGUtVG+pWw0XxD3LDiPyNs+TKmEWYK7\/Jzx1E=",
      "url": "_framework\/System.Net.Sockets.dll"
    },
    {
      "hash": "sha256-CiGohu7QDSsOWWFmYLGX97ytcWIKZamOZFarFkqSmY8=",
      "url": "_framework\/System.Net.WebClient.dll"
    },
    {
      "hash": "sha256-ukn\/MxE8eNsJuQz5jlkkesFbegjJEHoD3\/R6q\/1UbQM=",
      "url": "_framework\/System.Net.WebHeaderCollection.dll"
    },
    {
      "hash": "sha256-zl7kO1lfGO7RIRSGMlBSOaGSH9Xr8DAEOq+YO15UlJc=",
      "url": "_framework\/System.Net.WebProxy.dll"
    },
    {
      "hash": "sha256-5ivV8xU1\/9tTQ5k10IYeFbxka\/RbBCJZgv7mm5ru+24=",
      "url": "_framework\/System.Net.WebSockets.Client.dll"
    },
    {
      "hash": "sha256-pIxHUdZ0ZKJKL09lrEicTA9f6SMIH1ZieB2vtWkdkwE=",
      "url": "_framework\/System.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-ORoukBxOLV9EuEfadatRLq3Vdy5GfTjbTqw36vdEfgs=",
      "url": "_framework\/System.Net.dll"
    },
    {
      "hash": "sha256-uOVAvWEuxf7TlaGw8HjAuoqpb9UTYXOWwAQOZrodqUU=",
      "url": "_framework\/System.Numerics.Vectors.dll"
    },
    {
      "hash": "sha256-c0U5GsxwuDE7S092rkx\/\/OiJ0QWWZ0X4YE30FsWO92U=",
      "url": "_framework\/System.Numerics.dll"
    },
    {
      "hash": "sha256-Nkk1wisTzXLA4u1xn5zk+nAzk4FLE\/xh5TnEzg4FtwE=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-arwimAx\/WncnRkVS7xfLr3MwwZmzbdMPC4j5fiGyZXQ=",
      "url": "_framework\/System.Private.DataContractSerialization.dll"
    },
    {
      "hash": "sha256-WiurvlheYbRx8ysjDNP1Fwet+T5Tgds31p0w83H5HU8=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-YGFDhFD7JLoYeM6slhxH10USmjaXPJfT3K5yaD5FbVI=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-mZFouHXuBqONeeAxvGLuHV9gP7ILq50BQUL2rY18hK4=",
      "url": "_framework\/System.Private.Xml.Linq.dll"
    },
    {
      "hash": "sha256-yCWeuFK6\/6xfkhoZQNACP0gEF+H0tXxLfCylvSHNlaY=",
      "url": "_framework\/System.Private.Xml.dll"
    },
    {
      "hash": "sha256-Qv+qD60y2z9fwmBgiK3c3M81n6e\/awvacnvPbr5z7tI=",
      "url": "_framework\/System.Reflection.DispatchProxy.dll"
    },
    {
      "hash": "sha256-wiYPkX5TZHmIlsKeuefYWjMr6pqat6TkFh5ohNMm\/Cg=",
      "url": "_framework\/System.Reflection.Emit.ILGeneration.dll"
    },
    {
      "hash": "sha256-V2yH8lSwu9ucm1rAxEkKSQRD0VtKCptVXIYohUtjrYs=",
      "url": "_framework\/System.Reflection.Emit.Lightweight.dll"
    },
    {
      "hash": "sha256-Ql0WfFhwqFx5kG9In7jN+SwxR70UORQJ0S2GteoDtIM=",
      "url": "_framework\/System.Reflection.Emit.dll"
    },
    {
      "hash": "sha256-3xlhK\/+3rgLd0GQ7dwBJ9zuEsqHsxFA3\/RijbXWlfQM=",
      "url": "_framework\/System.Reflection.Extensions.dll"
    },
    {
      "hash": "sha256-R74aWMpZT2vtTsD7mZFqDPfytKOkTYOYnANCfX57SRQ=",
      "url": "_framework\/System.Reflection.Metadata.dll"
    },
    {
      "hash": "sha256-iKwZKautkXqrDva6YEvnia\/PBymRRzYX6vvOl1kC5zY=",
      "url": "_framework\/System.Reflection.Primitives.dll"
    },
    {
      "hash": "sha256-\/GzNtq5OmOOqBpsW7+TQYfakXb5KR2W2YmMYRYx7kOU=",
      "url": "_framework\/System.Reflection.TypeExtensions.dll"
    },
    {
      "hash": "sha256-UW74kIFzGKTGy9HAcbtYpUWXA\/B6GTPHRtnr7M\/BCS4=",
      "url": "_framework\/System.Reflection.dll"
    },
    {
      "hash": "sha256-U9M4RTr\/Om9jbyzoaJnpgx1ilfUYSZkjdnVqXVQ1sIA=",
      "url": "_framework\/System.Resources.Reader.dll"
    },
    {
      "hash": "sha256-LyTr2qbfUiMxccvMVHF4Q5JtgutPhcq5GWpKt8FYjnY=",
      "url": "_framework\/System.Resources.ResourceManager.dll"
    },
    {
      "hash": "sha256-qF6Td7oiyYEK8gQwdXLK0+Y8zgdVr6nle55wE08A2nE=",
      "url": "_framework\/System.Resources.Writer.dll"
    },
    {
      "hash": "sha256-VsQnT19iycrPJ9BlTP6M6eAl6p1rrYgWhVNkK\/SuD4c=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-JXvLzhZLKjcwIE5YW3SPUVnUApbEc1MeVYouxvOKGys=",
      "url": "_framework\/System.Runtime.CompilerServices.VisualC.dll"
    },
    {
      "hash": "sha256-z466D4g0zQFBSNtpGL4+K6Mdi4aAc8HSqdbdldCcoS0=",
      "url": "_framework\/System.Runtime.Extensions.dll"
    },
    {
      "hash": "sha256-EDgkL1Z18gklX0aB4mk36zTx4mR2LtH7R4Hgw2Rrirg=",
      "url": "_framework\/System.Runtime.Handles.dll"
    },
    {
      "hash": "sha256-YGSiFOUNNeTvLduMNGb9RzZNX4kgV3RettHF2f1+VyY=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-8aAD7\/LSno0zSA1gndlm1zkDZ7Nf2Q09aF2dZxIG2oo=",
      "url": "_framework\/System.Runtime.InteropServices.dll"
    },
    {
      "hash": "sha256-+m6RTJbzgoKXQQFF7I7jWRrwnO6byXLfPWwOjN+L1zA=",
      "url": "_framework\/System.Runtime.Intrinsics.dll"
    },
    {
      "hash": "sha256-mumcMb07Yv\/50Idc4bGbGlXDjY9NHrLFgblnpJLkN5c=",
      "url": "_framework\/System.Runtime.Loader.dll"
    },
    {
      "hash": "sha256-FtKuqFWzvBuaPFh0+Sl\/V0BKoFkqsMr6c0XTZoSSL9k=",
      "url": "_framework\/System.Runtime.Numerics.dll"
    },
    {
      "hash": "sha256-q0BNlJWUdOuC9qbvK3sXw5XIgB5bMyeE0OjCtSiIfuU=",
      "url": "_framework\/System.Runtime.Serialization.Formatters.dll"
    },
    {
      "hash": "sha256-71FxVS66+W\/K+bEL2HRwrQ+CJTrLaJ4vEavuGrwU4VE=",
      "url": "_framework\/System.Runtime.Serialization.Json.dll"
    },
    {
      "hash": "sha256-HVD1IxoEP8vqYkJ\/MNNHcPV1Zo\/b23dSwdr5Jm+xMNQ=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.dll"
    },
    {
      "hash": "sha256-S5jyL3OZ3dT\/uLBX8FeGvmUjwok\/3PBqx5Eev70IS50=",
      "url": "_framework\/System.Runtime.Serialization.Xml.dll"
    },
    {
      "hash": "sha256-ki5WkxHiavO+Q+6Pmgtcmt3AJr0gmzZeMIthoV3b\/8E=",
      "url": "_framework\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-abxOSyg6c+1hRIpXLcC8clizxf46+fPuzJNI4bVc7Cw=",
      "url": "_framework\/System.Runtime.dll"
    },
    {
      "hash": "sha256-swk3iJciSwGU+TzuS8PA+iKR2B2yaCc4fkQuKRCEW5Q=",
      "url": "_framework\/System.Security.AccessControl.dll"
    },
    {
      "hash": "sha256-wFvMhd98a3hpmF9TKnSsf3tTePtHU0rbFGgOGIxlazI=",
      "url": "_framework\/System.Security.Claims.dll"
    },
    {
      "hash": "sha256-YKkoq8SydFEY0W+xDo+Y7Ov1BOBmsi7Zjdi60Q6JDSA=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.dll"
    },
    {
      "hash": "sha256-DrJaFJq3bAsjnk0GplEqLYyDuGsST+hIyqpN4+TeAI8=",
      "url": "_framework\/System.Security.Cryptography.Cng.dll"
    },
    {
      "hash": "sha256-KV3E1wcTqdOgOZTxaciaumC3NVTfJAbnXWGtNTNJS9E=",
      "url": "_framework\/System.Security.Cryptography.Csp.dll"
    },
    {
      "hash": "sha256-ux1F87ykrd+5xUhmmjtQXnRMkSz3MEzVMwBbLUhOJAw=",
      "url": "_framework\/System.Security.Cryptography.Encoding.dll"
    },
    {
      "hash": "sha256-apTB0u+i0P2hvzF3dyAMWAGAo+WNZvugsgxM93y+Ry4=",
      "url": "_framework\/System.Security.Cryptography.OpenSsl.dll"
    },
    {
      "hash": "sha256-LGODOFNWB3q4XGbkYxbx+WeSFz+uOT2qFWgbcodQEv0=",
      "url": "_framework\/System.Security.Cryptography.Primitives.dll"
    },
    {
      "hash": "sha256-y4snQRuUzvSJCUMj2c3IOQkuFYWfOZoVqNXxpWySFAk=",
      "url": "_framework\/System.Security.Cryptography.X509Certificates.dll"
    },
    {
      "hash": "sha256-Ik1zRVCAXZ0xYFaUwHarl7cmA05ealzG78xiDUT42lU=",
      "url": "_framework\/System.Security.Principal.Windows.dll"
    },
    {
      "hash": "sha256-XIhANNkv3mgxJxzTDXBN+cTLVFlySd4x14YLftZIz9w=",
      "url": "_framework\/System.Security.Principal.dll"
    },
    {
      "hash": "sha256-djAxeFtIt5ZSRxZFpcVraAjLlVOvsoxy+3zD+5SSiC4=",
      "url": "_framework\/System.Security.SecureString.dll"
    },
    {
      "hash": "sha256-e80jJry39dSYxq5ry6KinHbtQTx78A9WQZglmv9kjZk=",
      "url": "_framework\/System.Security.dll"
    },
    {
      "hash": "sha256-DBUw7I8spkPm30LGeTXuKzVPxGu1CqRSYkhh8JPc8Vc=",
      "url": "_framework\/System.ServiceModel.Web.dll"
    },
    {
      "hash": "sha256-sshPWch3lbmx2YJf5FfVomCllczHCxmVYYHI14xOTeI=",
      "url": "_framework\/System.ServiceProcess.dll"
    },
    {
      "hash": "sha256-XWO5Dy2LbVojGIlSB8Z6nVBDKzaFqkVc+Z3epZfSyM0=",
      "url": "_framework\/System.Text.Encoding.CodePages.dll"
    },
    {
      "hash": "sha256-eodpKplB3vABFMLUiKvS3DPOhmveI\/Aah2Ue+4EPOfY=",
      "url": "_framework\/System.Text.Encoding.Extensions.dll"
    },
    {
      "hash": "sha256-MBDih\/9VvIN9zToEpDHT0Yp9J4y2rnciu+Z2d\/7t2Ww=",
      "url": "_framework\/System.Text.Encoding.dll"
    },
    {
      "hash": "sha256-rh6PaTDY\/mEtHdU\/neotU+tjnESJ7MurXKm1jTMYmNg=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-mFd0i54JKDD70UgV5hx\/3BqNfYNCFu5j8GYtNe2vyOc=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-8C9Sij9yJayBYivvN6jyBnRmnGJTgtKvShLyL3aSvUA=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-2UQyu5M4B+2lFDcT7zHk291\/kkZ74RaJO8LAJuZUjpc=",
      "url": "_framework\/System.Threading.Channels.dll"
    },
    {
      "hash": "sha256-+6CX1g45ADTwrZH+w8xgSr2OS0BPBtPuFBCXi8A2D08=",
      "url": "_framework\/System.Threading.Overlapped.dll"
    },
    {
      "hash": "sha256-lM0JcUqpQgFip\/Mtqelgzt7PFp+t\/g9PWkICu+WBzjk=",
      "url": "_framework\/System.Threading.Tasks.Dataflow.dll"
    },
    {
      "hash": "sha256-b\/YaHolTgshG73MU6AhV+EI+XV1MHGXJYYQqaX4jL2w=",
      "url": "_framework\/System.Threading.Tasks.Extensions.dll"
    },
    {
      "hash": "sha256-jx7CnGNGxEATKh4cP9WnzWgKbBwBU26Ont2FnRSm00s=",
      "url": "_framework\/System.Threading.Tasks.Parallel.dll"
    },
    {
      "hash": "sha256-YDu\/ib5GAx4buPjqZiYXYCE7N6fOzNOcauFU\/Y0+epQ=",
      "url": "_framework\/System.Threading.Tasks.dll"
    },
    {
      "hash": "sha256-Y++OB8vuDgV0ydWRq7UEW9uPd1isMwvAKcuK1fBZqGQ=",
      "url": "_framework\/System.Threading.Thread.dll"
    },
    {
      "hash": "sha256-KUdoq9jS1QyXnxhtQ3svziINr7RjWECVpzUfj9hpeQ4=",
      "url": "_framework\/System.Threading.ThreadPool.dll"
    },
    {
      "hash": "sha256-fhzguKUVjh6IJ8cJm7s3OVJ6dfeNKw3ruELQ7r\/7Vws=",
      "url": "_framework\/System.Threading.Timer.dll"
    },
    {
      "hash": "sha256-NIXoLVtkFgHRcMZHplD7Lj2xwkBBRJU6v2H8skqlJWs=",
      "url": "_framework\/System.Threading.dll"
    },
    {
      "hash": "sha256-o5vmfjWdde5MloQhx6x1FeL2T9Gz0vdTZehfAk1Gtb8=",
      "url": "_framework\/System.Transactions.Local.dll"
    },
    {
      "hash": "sha256-d\/HQbfArFT3KAVNe59bgFVIRI54Lue7nKY5+q5VzUC0=",
      "url": "_framework\/System.Transactions.dll"
    },
    {
      "hash": "sha256-EnERZdIx8kQui7peV0NctmAvq1vMtz0ebj63EV6I0xE=",
      "url": "_framework\/System.ValueTuple.dll"
    },
    {
      "hash": "sha256-eLQWpuY93tCqNqe55tmHPfAj9LrD65BQQ3gegVWPHhM=",
      "url": "_framework\/System.Web.HttpUtility.dll"
    },
    {
      "hash": "sha256-fM7llvbaw3ARzDeaa\/3wUFq2JN1s7fvERhYNJR\/TRQM=",
      "url": "_framework\/System.Web.dll"
    },
    {
      "hash": "sha256-1TndOK5uYPgV4z4xT+JFJaFpAlKOgeabw1\/vXnODdGQ=",
      "url": "_framework\/System.Windows.dll"
    },
    {
      "hash": "sha256-bD95ESqTPMKYi9nEkv8dmsKZok7Ic8hTv2C8Ancb7nE=",
      "url": "_framework\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-lSDnPPCGt1rENbmbG3pgvlVqr7YtOs\/dxUaLatXwOEc=",
      "url": "_framework\/System.Xml.ReaderWriter.dll"
    },
    {
      "hash": "sha256-ItHoj\/1D8B7\/xdXxlW3K1O6juo7xBs0C4lIvNNMUZNI=",
      "url": "_framework\/System.Xml.Serialization.dll"
    },
    {
      "hash": "sha256-UbVuI1u8TB8gju\/0KMQn3uMRRFrGF9SPA9Ti5LgXiws=",
      "url": "_framework\/System.Xml.XDocument.dll"
    },
    {
      "hash": "sha256-0eptSY9LC8tTNfb9kOgkzxEdqFSN6wPLvTeCx2+Vd4g=",
      "url": "_framework\/System.Xml.XPath.XDocument.dll"
    },
    {
      "hash": "sha256-H3nfr0rUfy\/Rc1NYVxi5EtBFk7yY4K34hMhU7aOS2dg=",
      "url": "_framework\/System.Xml.XPath.dll"
    },
    {
      "hash": "sha256-l0tlC5N\/z+\/9j0qXuSgTD4+mcQwgJ1AfbMwzplxt99w=",
      "url": "_framework\/System.Xml.XmlDocument.dll"
    },
    {
      "hash": "sha256-GTzHVTJBmWB\/EsQjoELs8UXJHgesihutu1dKtR6AP04=",
      "url": "_framework\/System.Xml.XmlSerializer.dll"
    },
    {
      "hash": "sha256-pFMFdzqRXoZXVxYQD45vQmLGpU8CCkHqMDmDhDH1GbM=",
      "url": "_framework\/System.Xml.dll"
    },
    {
      "hash": "sha256-9b5k26z0yxzVlLsAbHu+RQ3Tna2E2YfPuoJ9xR6g8Q0=",
      "url": "_framework\/System.dll"
    },
    {
      "hash": "sha256-rz66V4H6MUg6PAn2fdp0uw3NiP1lQ3cZ5ITKqz8ADKA=",
      "url": "_framework\/WindowsBase.dll"
    },
    {
      "hash": "sha256-CbcIR45\/xUFaZJqGIle6bb7v2kWYjp4kOFpKNnCkd4I=",
      "url": "_framework\/mscorlib.dll"
    },
    {
      "hash": "sha256-qE0Q70OyVlHYY\/Y3nwMjfh+zissea9uhfvWMvPWfI7w=",
      "url": "_framework\/netstandard.dll"
    },
    {
      "hash": "sha256-pdkcl2+OojCfrhxX5eFmKI30wAmhL6s+sCLp7s175k0=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-ootDKSA6cNAbgJLmPhrHsPVvVqkGEYdRZxucC22LWjw=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-YXYNlLeMqRPFVpY2KSDhleLkNk35d9KvzzwwKAoiftc=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-lg8Ao7vtV0csLoUmg4UFKwQPAk9H1pbzQBbcF9D42vg=",
      "url": "_framework\/dotnet.5.0.15.js"
    },
    {
      "hash": "sha256-UlFawE3BXRLCKVMHrerhXlh4kYvehGs2EvDFq8J51RE=",
      "url": "MonstarBookTools.styles.css"
    },
    {
      "hash": "sha256-6rmYZiFiwqQ83yD48iFPcKeua1\/CJWvXt8yPJMkBp98=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-D9rvoAtZHyuc8nc3waer53g8nvnTU+j8SiCgqV7Apgw=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-+eP8ll\/XZXhmE6YTM+AMoIDZ\/eflqTH2OLxMjFCd0zc=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-R6lgTmWZQPc8zEQZSIkTb6Cw6TRDR9DlssL\/q1fTG4g=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-F9I+0e7EyaafnAUWdWoVvklWg1Fj5AQpEpDvLA9WQ7U=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-DcTOo9gXOu6Rpr8D85aQmt5KRX\/v1xwAZLlldyUHK3E=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-sFLIXlNE+1rsIVDR7vHabGMLsLCzlNOaBgPZSlix\/bc=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-nFOzP2WKCWLDJkaeR8scIWbsDRPdHVZc6uCoIgYwLgY=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-ItVqY6H2CkoU21V\/k6WwyVs553TJsixjYW08mF43mn4=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-1qMpq0WGanfSymZ7G9G2miVo\/3nU28VSxiJkuAkU6m4=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-G+pRSzA7e8kfyDv69bfOqUSGBuMfM+PsRIetL71fwd4=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-vpj6p5lL2M+GsRVAI+VVi3I\/dpflkVJLcloOS52D\/\/8=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-qPIvEaHuBRFKLKbFwUK34ATZV69kdVFC+lzKmpVMxpQ=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-PotMOSV6NCm1RFdQpG4oXzBipnkMHmHEr\/7e4q90k5k=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-3ET+mpR7F058YRj9YaLHOVXBqOW6iUxtIpeiKPYw4PA=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-P32d2Q\/0GHTqjaSv3QYbVzlxGyE3bHdkqDz6gXH1sDk=",
      "url": "_framework\/MonstarBookTools.dll"
    },
    {
      "hash": "sha256-Box5eo26rGb3\/G9CdbjI6eOXhf942ky7Pi+vpyTwN4I=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-dl8FVRvWOJfOtzIC\/x66QNnBNsT9cAOMrn22GB8fJ8U=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "\/wVg7Wq0"
};

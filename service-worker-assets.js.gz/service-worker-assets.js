﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-m1j9QKrzS4aarePvS1ujYGAkqMTr3F4cFN0ipNeESWs=",
      "url": "card-images\/Card01_01.png"
    },
    {
      "hash": "sha256-Q+vRE1PnkMxPdONa0\/7ebzHqoWUY+OPy7XviIB2UYAo=",
      "url": "card-images\/Card01_02.png"
    },
    {
      "hash": "sha256-iDaSpY42bZ0uzhYsjQtzQxZy8uFa8SbTis5UutLIfTk=",
      "url": "card-images\/Card01_03.png"
    },
    {
      "hash": "sha256-aPL0E\/2rbiYOKafG1dFli+jJJM5+2jhXw9NesS9qjxs=",
      "url": "card-images\/Card01_04.png"
    },
    {
      "hash": "sha256-cmTq2CY5pyukMj2YRFrTq6yGjqYyXex\/YxIh3roykc4=",
      "url": "card-images\/Card01_05.png"
    },
    {
      "hash": "sha256-5O03E0QqXZYnSz5DN75aZC4z5sBQSXd\/AUPHT0f5vwM=",
      "url": "card-images\/Card01_06.png"
    },
    {
      "hash": "sha256-V6MwZqrD6Kn+Rl9M6tAZSr3c2j9WPcnv4gAyeTEFT6Q=",
      "url": "card-images\/Card01_07.png"
    },
    {
      "hash": "sha256-BzahjDwxTwnfuAWNUCdaejfzNmdABFRPxrJJMXYwc30=",
      "url": "card-images\/Card01_08.png"
    },
    {
      "hash": "sha256-7rATCS3gACYzUmneV1JHfui9R6G1aMx6d08nkZhgwEw=",
      "url": "card-images\/Card01_09.png"
    },
    {
      "hash": "sha256-rOOsHWebU9nnJxvkrt\/4+ED5um8aTurKHXLWZ\/aEBnQ=",
      "url": "card-images\/Card01_10.png"
    },
    {
      "hash": "sha256-Wvvq0LSLXUXeRC21rE7rkP25MeL1u3eHw4ut22\/gX4k=",
      "url": "card-images\/Card01_11.png"
    },
    {
      "hash": "sha256-ethFFuzjRCPt157nvVZGSFAzDib44R\/arctWNpywNig=",
      "url": "card-images\/Card01_12.png"
    },
    {
      "hash": "sha256-5HBFlQTnj85cVbheOLU+5f1HflxqxGVIOblbsiYPfLw=",
      "url": "card-images\/Card02_01.png"
    },
    {
      "hash": "sha256-UTlkFJUCnODh3QsTHaBnkiayqW5qloUQhAxPBWBf\/b4=",
      "url": "card-images\/Card02_02.png"
    },
    {
      "hash": "sha256-3c8Fxvlge4YtVfoWyUsBOPmFHJiroBLaUef+Jaa49dg=",
      "url": "card-images\/Card02_03.png"
    },
    {
      "hash": "sha256-Szjyie4O0LrxQo3UuIY9ypH+NKk7GUGUWZvOjYVEfx8=",
      "url": "card-images\/Card02_04.png"
    },
    {
      "hash": "sha256-CzwfRJiTP1SWDunlxLbYLOI8Wiao83\/PgrF0aPP8Gt8=",
      "url": "card-images\/Card02_05.png"
    },
    {
      "hash": "sha256-0TcQYTUwxBgiuwMV9efKtt\/sf7SF6sLmG+0NUw2jZ84=",
      "url": "card-images\/Card02_06.png"
    },
    {
      "hash": "sha256-zRwiHsXrc46HGIMUoXu+JtLtCsqWa000lxf99hGBtoc=",
      "url": "card-images\/Card02_07.png"
    },
    {
      "hash": "sha256-aHOANSUHuIiq0hn37NGqGOZzC6laoQuQpIwPJeaPDXI=",
      "url": "card-images\/Card02_08.png"
    },
    {
      "hash": "sha256-Gakjr9nOYihezMmxXvmfzDUABalGnoG64VgdLOfvaDc=",
      "url": "card-images\/Card02_09.png"
    },
    {
      "hash": "sha256-Gsc8z5114jcLkwYhUxB9bQkVh+XDLXRjmhbQ5gX\/qVc=",
      "url": "card-images\/Card02_10.png"
    },
    {
      "hash": "sha256-U28sdfZbiQJ47LCUq\/AyU3fdKM8oZupx\/A7nyxn\/3tY=",
      "url": "card-images\/Card02_11.png"
    },
    {
      "hash": "sha256-JhaDDdL\/hbN7mQygJlIj9r9VilVlN52P34AX2B+bCMk=",
      "url": "card-images\/Card02_12.png"
    },
    {
      "hash": "sha256-JWUyMaAKxRLcizHa9SVZGy4ejT9K4cXodHvTB22Uonc=",
      "url": "card-images\/Card03_01.png"
    },
    {
      "hash": "sha256-w2avPtyEGNfgGFuz4YPAzuDkKqACLZ6wNncaoCi1AN4=",
      "url": "card-images\/Card03_02.png"
    },
    {
      "hash": "sha256-88I3Pwi6hzf9q+60TbjXz6MxJJKQsc6AjZqlITv\/p0w=",
      "url": "card-images\/Card03_03.png"
    },
    {
      "hash": "sha256-g\/7Usneo7AcKjXBUmlZ+bDJEagI\/k49rqqd5Gmr8Clg=",
      "url": "card-images\/Card03_04.png"
    },
    {
      "hash": "sha256-Phil9e157iRJLYU094TsOTEBR4wSUhwDfcc4sHk+c0Y=",
      "url": "card-images\/Card03_05.png"
    },
    {
      "hash": "sha256-Tl3uJyBprDdF1FnxsCp5cHMilHlH6FPREW06veeOQ3Q=",
      "url": "card-images\/Card03_06.png"
    },
    {
      "hash": "sha256-J0hhnk+ZFbjE5CmL4KTmhtuRxFKifWl1\/xjUQeYfyrE=",
      "url": "card-images\/Card03_07.png"
    },
    {
      "hash": "sha256-CP+eB\/JpppVGpFkZGLUXr49hwoutBQNfyEAXjlR+FLE=",
      "url": "card-images\/Card03_08.png"
    },
    {
      "hash": "sha256-rOZb8om2IZ\/5zRW6jxRoYJDhy18xXfp2fQ+GBRV5Ht0=",
      "url": "card-images\/Card03_09.png"
    },
    {
      "hash": "sha256-z86Jb50o7g6MrqVYbmiLXrf8hNn1HY8Bkt1AzErNOyM=",
      "url": "card-images\/Card03_10.png"
    },
    {
      "hash": "sha256-Cne3cAabYCBGcnlQIKJKl3lR1CnoD1n32Y8lXvGpwpg=",
      "url": "card-images\/Card03_11.png"
    },
    {
      "hash": "sha256-XlDJRwtcvLaTEemxVbjt4FYmEph4v2thKexkNIUnQ48=",
      "url": "card-images\/Card03_12.png"
    },
    {
      "hash": "sha256-uBrFz+8nA2UHTbiC842WGQIam44adJe+f2jSqmdn660=",
      "url": "card-images\/Card04_01.png"
    },
    {
      "hash": "sha256-FgyX2\/F6x5USQf88Voz9yLfyYoLO+TlsZ9LscMIPWng=",
      "url": "card-images\/Card04_02.png"
    },
    {
      "hash": "sha256-WJ8T7lf5dz6fmTsnwz6CfT8qK8uIyY0QKWi\/NMBuiG0=",
      "url": "card-images\/Card04_03.png"
    },
    {
      "hash": "sha256-G2kCxwyCQ6gsN7nAr9ZeoRHF+73gRHx47XNkbjtPkvw=",
      "url": "card-images\/Card04_04.png"
    },
    {
      "hash": "sha256-FANhLRHpQoq2biM4rKGT\/tYw1+yijmObxNMBLTH8D60=",
      "url": "card-images\/Card04_05.png"
    },
    {
      "hash": "sha256-yC0NAdOtvY4X50BMz1hTmjZHr\/FtqIhvl1YApe3J7Eg=",
      "url": "card-images\/Card04_06.png"
    },
    {
      "hash": "sha256-ftisnI2u4VaoyXdffpruZfEIiJN7Bi39Zxnby8Zu0Qc=",
      "url": "card-images\/Card04_07.png"
    },
    {
      "hash": "sha256-BDiWdmFY5cHEYYdGomxxLAQbs1b42nl5LAoZvVIDhLI=",
      "url": "card-images\/Card04_08.png"
    },
    {
      "hash": "sha256-IT6nWrzm7r4cp4coqBV+x1Sqm3ohC+t8k92FtV03Tk0=",
      "url": "card-images\/Card04_09.png"
    },
    {
      "hash": "sha256-zd4pSQDvj2iOoaManHphblFt5WwJrgwcgZrXoYrxAJM=",
      "url": "card-images\/Card04_10.png"
    },
    {
      "hash": "sha256-W1Nuc5q8JzWBY49HyBV\/l7cBGSp285qNokF8IhjgbEI=",
      "url": "card-images\/Card04_11.png"
    },
    {
      "hash": "sha256-RgeLj7T93G0aNkTgUyvNbg9T1yOgxHt9ARWC2PKLFps=",
      "url": "card-images\/Card04_12.png"
    },
    {
      "hash": "sha256-X0OvXAV24CbVci9RTC2kCFCDG\/i5r0UzDL8569CtZZ0=",
      "url": "card-images\/Card05_01.png"
    },
    {
      "hash": "sha256-AoPFvTtZwWBCOF797FFT0AZSnUNSlgiAfCa3NB75wAg=",
      "url": "card-images\/Card05_02.png"
    },
    {
      "hash": "sha256-CzSzq3dREQLkx9qSAwnp2t1sF6+ZqM4XplULEzLkhWE=",
      "url": "card-images\/Card05_03.png"
    },
    {
      "hash": "sha256-ytyceZ\/0JXI\/wJHhRZPRKxFI5p6tGSUMYxbCaTPABXc=",
      "url": "card-images\/Card05_04.png"
    },
    {
      "hash": "sha256-6GyHqSGVZQhhva4lfqBkyso7zu6ccIdITVf5urjGnAE=",
      "url": "card-images\/Card05_05.png"
    },
    {
      "hash": "sha256-kw\/38Yb+XSL\/hJJNiaSo3zbRcG+EcN7nKopfmmxJ++8=",
      "url": "card-images\/Card05_06.png"
    },
    {
      "hash": "sha256-Gcvg36VN3KdTG5exbjbuYlFGTyf34W7TqgX6qi66myQ=",
      "url": "card-images\/Card05_07.png"
    },
    {
      "hash": "sha256-i7xezKnSkMDOrjcWCmYcHkKkX7i7CGU3gIaayAmtA\/c=",
      "url": "card-images\/Card05_08.png"
    },
    {
      "hash": "sha256-XDNP5Aq5D8E2jgE8fouUEr80FSOhEo9eFZlj645NR6c=",
      "url": "card-images\/Card05_09.png"
    },
    {
      "hash": "sha256-GoSaVXdqZxJGMGosqDDhkCckDDzU53P25WWLvm62MgU=",
      "url": "card-images\/Card05_10.png"
    },
    {
      "hash": "sha256-WRTqZynY98bnhDN+qcghLHxyZrfkxi58MlrZAZBNd9A=",
      "url": "card-images\/Card05_11.png"
    },
    {
      "hash": "sha256-\/jar\/pUir+wXZEHYyPoXHRM+KIzfjt6Jx1mGJ1OcbLY=",
      "url": "card-images\/Card05_12.png"
    },
    {
      "hash": "sha256-0y\/rhND1AlTCA\/T+15sVP7sLBblGqGhMCNVO1Jh5BFA=",
      "url": "card-images\/Card06_01.png"
    },
    {
      "hash": "sha256-BTypNIj0dRcexh2YtdjfyFcW+Kp\/0TbD3Yi9VrsccpQ=",
      "url": "card-images\/Card06_02.png"
    },
    {
      "hash": "sha256-Z76s9rR1MS7XHh8sROdSRhBMhIKFTq5TU5bAi+\/BGV8=",
      "url": "card-images\/Card06_03.png"
    },
    {
      "hash": "sha256-OU7z2YsMet9WEx2HmmOFGNvrSZOTgBsRNsfSaQYKajA=",
      "url": "card-images\/Card06_04.png"
    },
    {
      "hash": "sha256-4JK+4aChh991vKY+FERpwNk8+lKp1fZUoUMQEvXrtwE=",
      "url": "card-images\/Card06_05.png"
    },
    {
      "hash": "sha256-hQz0BglVt+IfLyEzb+1Z9bSJimUVYat3dxQeIEb8Fok=",
      "url": "card-images\/Card06_06.png"
    },
    {
      "hash": "sha256-HswL748+1u9dXDcsHFkPY8VBFv4sVCQqPxSGEZY0LlQ=",
      "url": "card-images\/Card06_07.png"
    },
    {
      "hash": "sha256-nqyyNfc3ZP4+FQ9ST2X\/VOnXShc8JAW6P4A2UeI8QHo=",
      "url": "card-images\/Card06_08.png"
    },
    {
      "hash": "sha256-2TxVomdBFdCzMVPJVpgX1cK+MiGaac8qe96ITATHgVo=",
      "url": "card-images\/Card06_09.png"
    },
    {
      "hash": "sha256-DHoyHq8NV39++qsqSYJZhEnYc7\/Fh2RZJIYgTdZp0sQ=",
      "url": "card-images\/Card06_10.png"
    },
    {
      "hash": "sha256-xfXcM1BApwZTH88svVxxSUn\/6UoxHOVyX3WHp0E5qLY=",
      "url": "card-images\/Card06_11.png"
    },
    {
      "hash": "sha256-cwmtWGpMGBDCnTFj5RoGXe0QUq6zcHtwYvlF4V6\/Upo=",
      "url": "card-images\/Card06_12.png"
    },
    {
      "hash": "sha256-JhLHoea3U4SCN\/nFL7VxDGc4EA4FLkXqPwp\/87QBRS0=",
      "url": "card-images\/Card07_01.png"
    },
    {
      "hash": "sha256-hwxZQx27lncgiz8bxsCin36nHQv5+xTSyZ1j6eg0YI0=",
      "url": "card-images\/Card07_02.png"
    },
    {
      "hash": "sha256-eFii9gl+9sq2644\/Tl2HXciCrM4y2e8pTcHox1wEgaM=",
      "url": "card-images\/Card07_03.png"
    },
    {
      "hash": "sha256-yQCkU80Ww3fOUEjk+xfbaZH7zeWalSlV\/CthTo3PjUA=",
      "url": "card-images\/Card07_04.png"
    },
    {
      "hash": "sha256-ptvNJampYopQgFTvJMgezpnQw9rtS\/mNmE7PB3a+uMA=",
      "url": "card-images\/Card07_05.png"
    },
    {
      "hash": "sha256-iKS2qZSWQ51PeqlTvMcwwdhksDCteWHv4b5nTWSsMkk=",
      "url": "card-images\/Card07_06.png"
    },
    {
      "hash": "sha256-4PDvzhG8N3B8VdPAl+Mf1Ldud\/Ry0nEw1FyYL52ivJ4=",
      "url": "card-images\/Card07_07.png"
    },
    {
      "hash": "sha256-MBSqICbWC\/GGUD1EqESKd6StJKFJvYcNx\/TGFc1Mfms=",
      "url": "card-images\/Card07_08.png"
    },
    {
      "hash": "sha256-rlq5iUSSsXNlLDcfOWWp9njUKrFgL6NIE9J5IjgSb6I=",
      "url": "card-images\/Card07_09.png"
    },
    {
      "hash": "sha256-RgTw6JiKsvCFMUKiGYp4PmGjnZz+AB\/EwDuxze2yP9U=",
      "url": "card-images\/Card07_10.png"
    },
    {
      "hash": "sha256-+ua55CpW8paCTW4GPyToUrbYE1nydnFlYh34pP\/Vctw=",
      "url": "card-images\/Card07_11.png"
    },
    {
      "hash": "sha256-TdCouiGccy5eXiJqXvS6YokJ1C79rOCH1l2YW5zdTD8=",
      "url": "card-images\/Card07_12.png"
    },
    {
      "hash": "sha256-RmPhsz3EFT5KvW\/Fk72ZndBu5J6PmvPZK8f\/g0AzYoY=",
      "url": "card-images\/Card08_01.png"
    },
    {
      "hash": "sha256-5NFFsftmCm2l\/LH\/AISwsxj8fnB2C1t0N9IC9lCN81U=",
      "url": "card-images\/Card08_02.png"
    },
    {
      "hash": "sha256-S3Nyf8kxY9zFTWPgm2XxDrxIVZe+r1CzFU7uhShsEpM=",
      "url": "card-images\/Card08_03.png"
    },
    {
      "hash": "sha256-i10aID\/QHxedw08X9DBkDNs7GXO2c9EJQed0aADHLdM=",
      "url": "card-images\/Card08_04.png"
    },
    {
      "hash": "sha256-Nof+9wUGstDQAghEdxlB5BVSGm6SN6so4MZoDBeBMR8=",
      "url": "card-images\/Card08_05.png"
    },
    {
      "hash": "sha256-R+yH2UdIj6ysF3s65M29vBra3XNx\/LKw17IJ7JOCrPA=",
      "url": "card-images\/Card08_06.png"
    },
    {
      "hash": "sha256-xijvKdl53ckUhqSVgZgXptZM45EyKxH3+rlKagMfJg4=",
      "url": "card-images\/Card08_07.png"
    },
    {
      "hash": "sha256-eWH9XIYr9cDRccwQyI5lgTEhZkGyUFE7e9Hi8u6qVbQ=",
      "url": "card-images\/Card08_08.png"
    },
    {
      "hash": "sha256-x9+h48oUdjERfQNbvM8HCkdJhBudx6FIBt2Xj\/3Ckpo=",
      "url": "card-images\/Card08_09.png"
    },
    {
      "hash": "sha256-CXkHLlySDvQx2aeuW22hHGwwiCtEVdrUS8SwXJHVmCI=",
      "url": "card-images\/Card08_10.png"
    },
    {
      "hash": "sha256-XbPcIc0wSXPItYOLwuWosZyUkNN1DS5yfcYzWQEDlhM=",
      "url": "card-images\/Card08_11.png"
    },
    {
      "hash": "sha256-OUfGoKo6ZokLQesR8oMU+ETfgMSsQ7bjfRu0Y1Cal4I=",
      "url": "card-images\/Card08_12.png"
    },
    {
      "hash": "sha256-7io1Oy2KseVyK0u62LW7vOqHx1N1OZSZQQ\/1KeXgeDw=",
      "url": "card-images\/Card09_01.png"
    },
    {
      "hash": "sha256-WFe+FdM5HFQ9J5tFM1zksfQ49nreZGislGQIML8GAJ0=",
      "url": "card-images\/Card09_02.png"
    },
    {
      "hash": "sha256-dnGpMhqgVev1KYtNv\/mouZ3rYPZ7ZWD5\/irEtA1C1FM=",
      "url": "card-images\/Card09_03.png"
    },
    {
      "hash": "sha256-qGCXXIMVL6hz7d5+\/sX+PTEoCkHgzD0mG47dvYQvM74=",
      "url": "card-images\/Card09_04.png"
    },
    {
      "hash": "sha256-YJ6bJLNvUlmaWSTlO8qifX0KL24q48a\/IT34JctskLk=",
      "url": "card-images\/Card09_05.png"
    },
    {
      "hash": "sha256-cs6p+z6veH53\/XBBQIPyGQzY+BjyC9JBiy2vZlyoJNg=",
      "url": "card-images\/Card09_06.png"
    },
    {
      "hash": "sha256-QqwXhfVmB5qSb1UoWiI\/B3KlkPdAqBhKnAwHTQWUoUQ=",
      "url": "card-images\/Card09_07.png"
    },
    {
      "hash": "sha256-BKbsAPpLg5x1pbqMoDHJSsBFe\/UaUHyxVfjsN1i6s5M=",
      "url": "card-images\/Card09_08.png"
    },
    {
      "hash": "sha256-N6zRQfpkRZHTItDvLMa9Q+WbkrEPiBKYw0ZzIV58Kqk=",
      "url": "card-images\/Card09_09.png"
    },
    {
      "hash": "sha256-QCG3qJxkg0mdlMBO6HI+qEctu3qWni8X4S37083GuI8=",
      "url": "card-images\/Card09_10.png"
    },
    {
      "hash": "sha256-W7\/7sL5m9iByqea08tYZ3wFNEgTlH2bYdxJuaZua8f4=",
      "url": "card-images\/Card09_11.png"
    },
    {
      "hash": "sha256-VvNZ0JmxXEZX8n53khGRY2nUHdzHFkAASTsQ6kh\/St4=",
      "url": "card-images\/Card09_12.png"
    },
    {
      "hash": "sha256-hgsKmGjecSrRq9Z\/MfTjS+JWRUgKY4FI6FvXcY8MreU=",
      "url": "card-images\/Card10_01.png"
    },
    {
      "hash": "sha256-MHi1RVgsWIAgZZ2qRXtLstHsILY4J988dFdN5u9bUwA=",
      "url": "card-images\/Card10_02.png"
    },
    {
      "hash": "sha256-Pdh957xG8CWbU7CfOq2CfIL62Vw2Frw4JUNN24GZvBI=",
      "url": "card-images\/Card10_03.png"
    },
    {
      "hash": "sha256-Buum2J\/Iz+xh2Bb+o\/9pFWmloptpc0C9MMRnKDeSifY=",
      "url": "card-images\/Card10_04.png"
    },
    {
      "hash": "sha256-NVk7+q5laB32UVsEmLGKKo1nompWXUbOjotEJMN4Y4E=",
      "url": "card-images\/Card10_05.png"
    },
    {
      "hash": "sha256-4R3VTz3wLs60Fknt+Ng4W2Ab0YQ2HRnO79FP7CTE9JI=",
      "url": "card-images\/Card10_06.png"
    },
    {
      "hash": "sha256-Nzu2MmZnp\/xQCURAfHMqumthu6zsYbMOt8BM3z051lQ=",
      "url": "card-images\/Card10_07.png"
    },
    {
      "hash": "sha256-atiYszHo\/pBxuX\/QKJ\/jJ7G71OW8xoAcMI0kpuBKbEI=",
      "url": "card-images\/Card10_08.png"
    },
    {
      "hash": "sha256-cxx6COlEDSISOEuttpc7vFOPDuLWXwNl3ze30C50aWc=",
      "url": "card-images\/Card10_09.png"
    },
    {
      "hash": "sha256-MFcBvpxrOJ0tKGqBGg8cW4WjjTarYMHcpUA69UtMqQU=",
      "url": "card-images\/Card10_10.png"
    },
    {
      "hash": "sha256-TmEQ5xcLAPu3SqAx7dyRHC\/xeSkw6YuOvkdnveJlXlU=",
      "url": "card-images\/Card10_11.png"
    },
    {
      "hash": "sha256-kJILNMI0nDwZf\/Mb\/9iBjlfZxsDrBCQiw4cIfqvkdkA=",
      "url": "card-images\/Card10_12.png"
    },
    {
      "hash": "sha256-Lx08HaN\/F7nK6gc+x7TpZBXZoHK+bNq\/v5lrCQsx6pw=",
      "url": "card-images\/Card11_01.png"
    },
    {
      "hash": "sha256-Z8QgbvsgwSaNZgxcqbquuWv68zZ24OYLrdrCD3G7IWg=",
      "url": "card-images\/Card11_02.png"
    },
    {
      "hash": "sha256-LH2HKKcHMESwkVSUGcXLOOwedvAs9miwJthMEKnwZns=",
      "url": "card-images\/Card11_03.png"
    },
    {
      "hash": "sha256-vnLlGePiwZeBJO3ug7z7XIiRvf9Qy\/2Nm5oHuXyUTmE=",
      "url": "card-images\/Card11_04.png"
    },
    {
      "hash": "sha256-3V8gvD61Le34wIstAh9zyeTs\/X7UtZzMs\/x02+t0bg8=",
      "url": "card-images\/Card11_05.png"
    },
    {
      "hash": "sha256-pxu6703+457RSOqt\/bacxyk6qZEKFCHXHAE6VzYj3M4=",
      "url": "card-images\/Card11_06.png"
    },
    {
      "hash": "sha256-iFxilNJAODVCLxTTkaOzprxSl\/g4Kw6ObEfWZ90AGaY=",
      "url": "card-images\/Card11_07.png"
    },
    {
      "hash": "sha256-Ekshreu0dVf4x+PUcra4BQK24sj10qp\/jnSxo70JypI=",
      "url": "card-images\/Card11_08.png"
    },
    {
      "hash": "sha256-XzJHcTOFvJrN\/+ze37ADkuhXpTKWltQKks+O1mUUxN0=",
      "url": "card-images\/Card11_09.png"
    },
    {
      "hash": "sha256-rs1KLTqEdxjNBHHNmsn39Qu6tjXsNgBx1Uv+qWhawQU=",
      "url": "card-images\/Card11_10.png"
    },
    {
      "hash": "sha256-fchiGwpala8ZR6BKeKS7nUQpxMEx4HMp3drpJTdeVOw=",
      "url": "card-images\/SpecialCard01.png"
    },
    {
      "hash": "sha256-eak7Y4rtUrv6ZXzs\/332j1Q+ekQzCirI\/WZ+MPLaUW4=",
      "url": "card-images\/SpecialCard02.png"
    },
    {
      "hash": "sha256-tftQ1iqs\/SyZE833G6SYqxSBrQTUnmt\/RdpnG7wGxo0=",
      "url": "card-images\/SpecialCard03.png"
    },
    {
      "hash": "sha256-PWj2XoXcONJnrS3tsCDKg55K8xTwgv7fSFKXB0KmUjo=",
      "url": "card-images\/SpecialCard04.png"
    },
    {
      "hash": "sha256-CR34DKwpi3J9xPtvzVIwQViScF3Naig6k5+iknXQkII=",
      "url": "card-images\/SpecialCard05.png"
    },
    {
      "hash": "sha256-AMcTmvREEYrvPE3VkWclnZJvrWvMUG4TlzQKnGbf5Fw=",
      "url": "card-images\/SpecialCard06.png"
    },
    {
      "hash": "sha256-Ebgqxqyixjgtu0GbUSAdCe2F2ciHl9YVkrlO4mFNSbw=",
      "url": "card-images\/SpecialCard07.png"
    },
    {
      "hash": "sha256-1+T9L1f3UGDYeL3RUr5jFZCkbW4xLfFS4C1NWhRDNxg=",
      "url": "card-images\/SpecialCard08.png"
    },
    {
      "hash": "sha256-8aM9R9K90X6h+KPDW4OzrEh071mAs7dvAQxjBxAZQAc=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-HKO7ntWaa3I4ZlebewiOofdXlkNFai7KbisWN06ONEE=",
      "url": "help-image\/1.png"
    },
    {
      "hash": "sha256-IfpxkW68S9wec6A5h4uSe9Le8njBAp0uBAk\/Bhxh5\/Q=",
      "url": "help-image\/2.png"
    },
    {
      "hash": "sha256-I7aoa01lCdlIR0Lw30REtr\/VlRFvkYNionU9QbMnIRw=",
      "url": "help-image\/3.png"
    },
    {
      "hash": "sha256-EL40n75eI78x4Bm8x7iQ09WYcDUcVcF6nae7VEHBAB8=",
      "url": "help-image\/4.png"
    },
    {
      "hash": "sha256-goUHZ5yyJlWBl+Ho0PxTjIFqEVdZ8alHe3QlNl+1j64=",
      "url": "help-image\/calc1.png"
    },
    {
      "hash": "sha256-EVJQJMyTGoMcbdQnCGQxznvCK\/J9cS\/vSSgOUikJ3Kk=",
      "url": "help-image\/calc2.png"
    },
    {
      "hash": "sha256-cnOsGDCUFuM6a0iIPLV5PlN\/KDzDcXqQJ+xD+GG0BT0=",
      "url": "help-image\/calc3.png"
    },
    {
      "hash": "sha256-rq1r3GP3qbLUy9dloaSMV1xHikV+Oq6d1ZPBSS+MI4c=",
      "url": "help-image\/calc4.png"
    },
    {
      "hash": "sha256-vPrzo9xx\/NDyI\/13Ypza2DWGIYG7cmTyB\/vehPIXDfU=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-sRvVf4XzqiGlCai9FkmO7W8wXyn0J\/00856dN97hATo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-yPV5vrdT9cIyWUhVsovux6Z9RNVEsvFOe4jE4cDiLk8=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-8oJip361m8OrfLRJOuIeswWKaoxtT27\/wINCxhn+s4c=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-YXYNlLeMqRPFVpY2KSDhleLkNk35d9KvzzwwKAoiftc=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-bN7gtVqP2mIpLB0ilKP5kcTBnBDitG1uYoLSnd\/WeBY=",
      "url": "_framework\/dotnet.5.0.17.js"
    },
    {
      "hash": "sha256-UlFawE3BXRLCKVMHrerhXlh4kYvehGs2EvDFq8J51RE=",
      "url": "MonstarBookTools.styles.css"
    },
    {
      "hash": "sha256-QPbnZhmIF216ApeCYtdpoe+6UBUp7hgAoXCm2X7f9l0=",
      "url": "_framework\/Microsoft.AspNetCore.Authorization.dll"
    },
    {
      "hash": "sha256-6Bo8uhd6Z5qX5uOGQQJ0pchc9e5CCYnrvszG4nEKTkA=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-ql9Q\/QAIT+uF\/N0a2H5IMmfIgbuGnzB43nnL2s9we9A=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-0I1hgN74mGBL+Zs3dRGBEuvSFKs2oJnHCZCgUwdUbkM=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-ac4stn1eobk9p\/24HUlvMqxpBymazpNVPsU3i5FCNKM=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-BJeRgbVSljLQ+sCKsDWwFbyJvkSF84fed7rcf5+GK4s=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-GcqOItT9TLap0aRlf66Tqc0ycCSRvh9ZZ2eP2AnyT90=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-tVIcXoAy9SgH+UQFCQG6f\/hmqrj8Bnwqz9AJaaLNsjw=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-P4+OD1nLY6yvBQbLWf3XALEAjGjsmOqrdAhj1SmCL1U=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-VtXlw8ZzXr\/uJukIxl2amVlI0iX5AudhX8bQF2k1mjI=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-zHBEMG1Q+YDH9wUwACWt9fET+rW7ddnUh7+QE6Q0FG0=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-YN\/6L13xwKXlQKSE2J4adk29vhT4SWM\/6Cz1R4E+tvI=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-UQLLfErWJmykNU\/8fVl1tpNwAVaDmX6UFcBr2P2SgMk=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-qPIvEaHuBRFKLKbFwUK34ATZV69kdVFC+lzKmpVMxpQ=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-PotMOSV6NCm1RFdQpG4oXzBipnkMHmHEr\/7e4q90k5k=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-3ET+mpR7F058YRj9YaLHOVXBqOW6iUxtIpeiKPYw4PA=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-moM8zFceKJvWHubJ5YQ4g8NGO9VLeF\/iX5LXGlSEihY=",
      "url": "_framework\/MonstarBookTools.dll"
    },
    {
      "hash": "sha256-8j\/d1uD8VduPLbeS+USAJ9Z\/kTKsZtrNguq4Henca9s=",
      "url": "_framework\/System.Buffers.dll"
    },
    {
      "hash": "sha256-xHvFu0jtFRQ7BJRL6wgLruzvocTk4DS0CQTLddNLAoo=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-XwJebLzmRzFwqh4oPh3lHvrfdw78UyegH0bS8HE6HKQ=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-inTYjigCXrmLQNBzFTJFYLcIpwsw+vIG57u65exZmBU=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-gCtKOUEVFj2v1P\/Q1LMwbnEZ4\/cQ\/7PglJ42+om8maw=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-oTxaVZXt9X0r9AJrOSSpbHPiJdR9iJ17JPu0gkkp0PA=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-LaHps0vrnsAcnQ7W8jjkf0T7X8KVeH08eFwBbcfvkbI=",
      "url": "_framework\/System.Diagnostics.Debug.dll"
    },
    {
      "hash": "sha256-U87MxzPN5x\/rn5oQogL\/OiRCmp32xCEdjIXLeWr5w44=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-3kmuJorAz0v4\/R0t6YN1V3oybHKboUHQqLYRHOrzbr4=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-2VPga0LUxgDqQRFqQgWHsTsWR8gCYqBKNyfc7q8bqEA=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-mHJG3tarxDrRFxWXdm6woJA4Wct3GbBB1W6AE9R+c+A=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-hjzWhRVMeCXP\/wCEIOLnAOm1bY9ndSrdnCpiI6ZSq4w=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-S6cZQ5HlaMDHSRAfmcF+29c3Qd7RrPEszq492OgBdn0=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-jpw9LFFxO8yKtz4nEmVYviTyntFGoFqsuJRr5S1SDKU=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-0NXGpfb+gtGRLmpERAhVFQKaKHR3sMv82x5rKcxb\/\/A=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-Cs1\/Ix1OJe4oyWwB9dTP1tR0+rv50UIffEQYFjkReXs=",
      "url": "_framework\/System.Resources.ResourceManager.dll"
    },
    {
      "hash": "sha256-3VHEMDUsNPFEmowJl1efp2CvvxfNHf5Qw1kvAqUrCns=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-w3PUJZ4Ndan2OiEXjG8FZvgBMSPxNVb\/R+eAbjtECFM=",
      "url": "_framework\/System.Runtime.Extensions.dll"
    },
    {
      "hash": "sha256-gdCNnYQIK+g3StY9zEUuVtsI6\/8jRtiBcAJdZPZkRL4=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-y\/NkZo7Tm8uodvXdg0ArtlXg4tz4kIWd6zfyykdki9Y=",
      "url": "_framework\/System.Runtime.dll"
    },
    {
      "hash": "sha256-DSbtBgUS49MADVa3GwIXM0mi4ZZgURIyo\/LxiP6aZ8M=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-zMhvDRVdeAFS5OYSfpR6p\/wfmOSJv7XxGQXXB5P75ZI=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-VbK4Htqad45ZRUe3P8pIBA4zy4+01Iui+VFlB45xjh4=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-XCI9ityfDYfAf8WP\/ZIuBdcQ1rEzQbHgG\/TofpUvtTk=",
      "url": "_framework\/System.Threading.Tasks.dll"
    },
    {
      "hash": "sha256-PNGkToQipDqwTh\/6z52NwdJ8GUk7wcG0dF2gzinDkmI=",
      "url": "_framework\/System.Threading.ThreadPool.dll"
    },
    {
      "hash": "sha256-yJGwdi0v0sW\/EmCNjECP8l\/3+rHA8jqjfjRTSmZy34Q=",
      "url": "_framework\/System.Threading.dll"
    },
    {
      "hash": "sha256-ldCoCSpl76+tqvCjx1HU17Ih8vh\/hBtRxmgLzK2cpl8=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-VXgF5rw8MB0ejjlLRJejym6LbcM8+4mYxtmWRNjMhrE=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-dl8FVRvWOJfOtzIC\/x66QNnBNsT9cAOMrn22GB8fJ8U=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "gr6Th+oO"
};
